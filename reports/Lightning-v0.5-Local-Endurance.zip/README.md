# Sequential local flight observations

Both are actual1200-wall-second flights on the same local cloud Chromium151/SwiftShader host, v0.5 then v0.4, with production diagnostics disabled and the existing normal governor active. No physical Galaxy A51 was connected. Source HTML hashes are in each raw JSON. Aircraft state is assigned only for the documented airborne initial fixture, then unmodified physics/autopilot run. The route can leave the photographic region.

These runs compare clock progression and stability. They are not a controlled rendering FPS comparison: corrected time changes progression, trajectories and workload; dimensions/governor can also change during normal flight. Do not infer Mali or physical display performance from these reports.
